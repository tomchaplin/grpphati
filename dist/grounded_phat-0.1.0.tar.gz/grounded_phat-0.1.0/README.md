## TODO

1. Implement non-regular path homology
2. Implement vertex-based and edge-based filtrations
3. Improve performance of sparse matrix construction?
4. Write test
5. Choose benchmark datasets
6. Benchmark different reductions
7. Switch to and benchmark `bit_tree_pivot_column` representation
8. Benchmark optimisations
9. Type hints
10. Test `_sparsify`; is it worthwhile to split the dictionaries on dimension?
11. Write README and LICENSE
12. Write `setup.py`
